function calc(a, b){
     return a+b;
}

console.log(calc(4, 5));